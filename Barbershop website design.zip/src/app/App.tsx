import { useState } from "react";
import { Phone, MapPin, Clock, Star, ChevronDown, Menu, X, Instagram, Facebook } from "lucide-react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";

import storefrontImg from "@/imports/unnamed__1_.jpg";
import braidsImg from "@/imports/unnamed__2_.jpg";
import colorImg from "@/imports/unnamed__3_.jpg";
import extensionsImg from "@/imports/unnamed__4_.jpg";
import cornrowsImg from "@/imports/unnamed__5_.jpg";
import geometricImg from "@/imports/unnamed__6_.jpg";
import auburnBraidsImg from "@/imports/unnamed__7_.jpg";
import stylingImg from "@/imports/unnamed__10_.jpg";

const NAV_LINKS = ["Services", "About", "Reviews", "Contact"];

const SERVICES = [
  {
    title: "Hair Braiding",
    desc: "Box braids, cornrows, knotless, and protective styles crafted with precision and care.",
    img: braidsImg,
    alt: "Long box braids with red beads done at Helen Hair Salon",
  },
  {
    title: "Color & Highlights",
    desc: "From subtle highlights to bold color transformations — tailored to your skin tone and vision.",
    img: colorImg,
    alt: "Beautiful highlighted curls styled at Helen Hair Salon",
  },
  {
    title: "Extensions",
    desc: "Seamless tape-in, sew-in, and clip-in extensions for length, volume, and versatility.",
    img: extensionsImg,
    alt: "Long straight auburn hair extensions at Helen Hair Salon",
  },
  {
    title: "Cuts & Styling",
    desc: "Precision cuts, blowouts, silk presses, and everyday styles for every texture and occasion.",
    img: stylingImg,
    alt: "Boho braids with curls styled at Helen Hair Salon",
  },
];

const GALLERY = [
  { img: cornrowsImg, alt: "Cornrow braids done at Helen Hair Salon" },
  { img: geometricImg, alt: "Geometric braid pattern at Helen Hair Salon" },
  { img: auburnBraidsImg, alt: "Long auburn knotless braids at Helen Hair Salon" },
  { img: braidsImg, alt: "Box braids with red beads at Helen Hair Salon" },
  { img: colorImg, alt: "Highlighted curl styling at Helen Hair Salon" },
  { img: extensionsImg, alt: "Auburn hair extensions at Helen Hair Salon" },
];

const REVIEWS = [
  {
    name: "Amara J.",
    rating: 5,
    text: "Love my hair! Ethiopia did a great job and was quick! Will definitely be back. The whole team made me feel so welcome from the moment I walked in.",
  },
  {
    name: "Destiny R.",
    rating: 5,
    text: "I went to this salon to get my hair braided and it was amazing! The people who work there are so friendly and super nice. My hair looks so great!",
  },
  {
    name: "Kezia M.",
    rating: 5,
    text: "Great Hair Salon! Always pleased with the service and my hair. I've been coming here for two years and wouldn't go anywhere else in Silver Spring.",
  },
  {
    name: "Tanya W.",
    rating: 4,
    text: "Beautiful results every time. The salon is clean, the atmosphere is warm, and the stylists really listen to what you want. Highly recommend.",
  },
];

const HOURS = [
  { day: "Monday – Friday", time: "9:00 AM – 7:00 PM" },
  { day: "Saturday", time: "9:00 AM – 6:00 PM" },
  { day: "Sunday", time: "10:00 AM – 4:00 PM" },
];

function Stars({ count }: { count: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          size={14}
          className={i < count ? "fill-accent text-accent" : "text-muted-foreground"}
        />
      ))}
    </div>
  );
}

export default function App() {
  const [mobileOpen, setMobileOpen] = useState(false);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setMobileOpen(false);
  };

  return (
    <div
      className="min-h-screen bg-background text-foreground overflow-x-hidden"
      style={{ fontFamily: "'DM Sans', sans-serif" }}
    >
      {/* NAV */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-background/90 backdrop-blur-sm border-b border-border">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <button
            onClick={() => scrollTo("hero")}
            className="text-foreground hover:text-accent transition-colors"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            <span className="text-xl font-semibold tracking-wide">Helen</span>
            <span className="text-sm font-light ml-2 text-muted-foreground uppercase tracking-widest">
              Hair Salon
            </span>
          </button>

          <nav className="hidden md:flex items-center gap-8">
            {NAV_LINKS.map((link) => (
              <button
                key={link}
                onClick={() => scrollTo(link.toLowerCase())}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors tracking-wide uppercase"
              >
                {link}
              </button>
            ))}
            <a
              href="tel:3015004783"
              className="bg-primary text-primary-foreground text-sm px-5 py-2 rounded-sm hover:bg-accent transition-colors tracking-wide"
            >
              Book Now
            </a>
          </nav>

          <button
            className="md:hidden text-foreground"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

        {mobileOpen && (
          <div className="md:hidden bg-card border-t border-border px-6 py-6 flex flex-col gap-5">
            {NAV_LINKS.map((link) => (
              <button
                key={link}
                onClick={() => scrollTo(link.toLowerCase())}
                className="text-left text-foreground text-base tracking-wide uppercase"
              >
                {link}
              </button>
            ))}
            <a
              href="tel:3015004783"
              className="bg-primary text-primary-foreground text-sm px-5 py-3 rounded-sm text-center hover:bg-accent transition-colors"
            >
              Book Now
            </a>
          </div>
        )}
      </header>

      {/* HERO */}
      <section id="hero" className="relative min-h-screen flex items-end pt-20" style={{ background: "#1a0e08" }}>
        <div className="absolute inset-0 overflow-hidden bg-[#1a0e08]">
          <ImageWithFallback
            src={storefrontImg}
            alt="Helen Hair Salon storefront on Georgia Ave, Silver Spring MD"
            className="w-full h-full object-cover opacity-50"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1a0e08] via-[#1a0e08]/50 to-transparent" />
        </div>

        <div className="relative max-w-6xl mx-auto px-6 pb-24 w-full">
          <div className="max-w-2xl">
            <p className="text-accent text-xs uppercase tracking-[0.3em] mb-6 font-light">
              Silver Spring, Maryland
            </p>
            <h1
              className="text-5xl md:text-7xl font-semibold text-foreground leading-tight mb-6"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Beauty That
              <br />
              <em className="text-accent not-italic">Speaks</em> For Itself
            </h1>
            <p className="text-muted-foreground text-lg md:text-xl leading-relaxed mb-10 font-light max-w-xl">
              Helen Hair Salon has been shaping styles and building confidence in Downtown Silver Spring. Braids, color, extensions, and styling — done right, every time.
            </p>
            <div className="flex flex-wrap gap-4 items-center">
              <a
                href="tel:3015004783"
                className="bg-primary text-primary-foreground px-8 py-4 text-sm tracking-widest uppercase hover:bg-accent transition-colors"
              >
                Call to Book
              </a>
              <button
                onClick={() => scrollTo("services")}
                className="text-foreground border border-border px-8 py-4 text-sm tracking-widest uppercase hover:border-accent hover:text-accent transition-colors"
              >
                Our Services
              </button>
            </div>
          </div>

          <div className="mt-16 flex items-center gap-6">
            <div className="flex items-center gap-3 bg-card/60 backdrop-blur-sm border border-border px-5 py-3 rounded-sm">
              <Stars count={4} />
              <span className="text-foreground font-semibold">4.2</span>
              <span className="text-muted-foreground text-sm">· 66 Google Reviews</span>
            </div>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <ChevronDown className="text-muted-foreground" size={20} />
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="py-24 bg-background">
        <div className="max-w-6xl mx-auto px-6">
          <div className="mb-16">
            <p className="text-accent text-xs uppercase tracking-[0.3em] mb-4">What We Offer</p>
            <h2
              className="text-4xl md:text-5xl font-semibold text-foreground"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Our Services
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-border">
            {SERVICES.map((service, i) => (
              <div
                key={i}
                className="group bg-background hover:bg-card transition-colors duration-300 overflow-hidden"
              >
                <div className="flex flex-col md:flex-row h-full">
                  <div className="w-full md:w-48 h-52 md:h-auto flex-shrink-0 bg-muted overflow-hidden">
                    <ImageWithFallback
                      src={service.img}
                      alt={service.alt}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-8 flex flex-col justify-center">
                    <h3
                      className="text-xl font-semibold text-foreground mb-3"
                      style={{ fontFamily: "'Playfair Display', serif" }}
                    >
                      {service.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed font-light text-sm">
                      {service.desc}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* GALLERY */}
      <section className="py-24 bg-card">
        <div className="max-w-6xl mx-auto px-6">
          <div className="mb-16">
            <p className="text-accent text-xs uppercase tracking-[0.3em] mb-4">Our Work</p>
            <h2
              className="text-4xl md:text-5xl font-semibold text-foreground"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Fresh From the Chair
            </h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {GALLERY.map((item, i) => (
              <div key={i} className="aspect-square bg-muted overflow-hidden group">
                <ImageWithFallback
                  src={item.img}
                  alt={item.alt}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ABOUT */}
      <section id="about" className="py-24 bg-background">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="aspect-[3/4] bg-muted overflow-hidden">
                <ImageWithFallback
                  src={auburnBraidsImg}
                  alt="Long auburn knotless braids — work done at Helen Hair Salon"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-4 -right-4 w-24 h-24 border-2 border-accent opacity-40" />
              <div className="absolute -top-4 -left-4 w-16 h-16 border border-primary opacity-30" />
            </div>

            <div>
              <p className="text-accent text-xs uppercase tracking-[0.3em] mb-6">Our Story</p>
              <h2
                className="text-4xl md:text-5xl font-semibold text-foreground mb-8 leading-tight"
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                A Neighborhood
                <br />
                Institution
              </h2>
              <div className="space-y-5 text-muted-foreground font-light leading-relaxed">
                <p>
                  Nestled in the heart of Downtown Silver Spring, Helen Hair Salon has been a trusted destination for locals seeking expert hair care in a warm, welcoming environment.
                </p>
                <p>
                  Our team of skilled stylists specializes in the full spectrum of textured and natural hair — from precision braiding and knotless styles to rich color treatments and flawless extensions.
                </p>
                <p>
                  We believe that great hair is more than an appointment — it&apos;s an experience. Come as you are and leave feeling your best.
                </p>
              </div>
              <div className="mt-10 grid grid-cols-2 gap-6">
                <div className="border-l-2 border-accent pl-4">
                  <p className="text-3xl font-semibold text-foreground" style={{ fontFamily: "'Playfair Display', serif" }}>66+</p>
                  <p className="text-muted-foreground text-sm mt-1 font-light">Happy clients reviewed</p>
                </div>
                <div className="border-l-2 border-accent pl-4">
                  <p className="text-3xl font-semibold text-foreground" style={{ fontFamily: "'Playfair Display', serif" }}>4.2★</p>
                  <p className="text-muted-foreground text-sm mt-1 font-light">Google rating</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* REVIEWS */}
      <section id="reviews" className="py-24 bg-card">
        <div className="max-w-6xl mx-auto px-6">
          <div className="mb-16 flex flex-col md:flex-row md:items-end md:justify-between gap-6">
            <div>
              <p className="text-accent text-xs uppercase tracking-[0.3em] mb-4">Testimonials</p>
              <h2
                className="text-4xl md:text-5xl font-semibold text-foreground"
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                What Our
                <br />
                Clients Say
              </h2>
            </div>
            <a
              href="https://maps.google.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-muted-foreground hover:text-accent transition-colors tracking-wide underline underline-offset-4 self-start md:self-auto"
            >
              Read all 66 reviews on Google
            </a>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {REVIEWS.map((review, i) => (
              <div
                key={i}
                className="bg-background border border-border p-8 hover:border-accent/40 transition-colors duration-300"
              >
                <Stars count={review.rating} />
                <p className="text-foreground mt-5 leading-relaxed font-light text-sm">
                  &ldquo;{review.text}&rdquo;
                </p>
                <p className="mt-6 text-accent text-sm font-medium tracking-wide">
                  — {review.name}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="py-24 bg-background">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
            <div>
              <p className="text-accent text-xs uppercase tracking-[0.3em] mb-6">Find Us</p>
              <h2
                className="text-4xl md:text-5xl font-semibold text-foreground mb-10 leading-tight"
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                Visit Helen
                <br />
                Hair Salon
              </h2>

              <div className="space-y-8">
                <div className="flex gap-5">
                  <MapPin className="text-accent mt-1 flex-shrink-0" size={20} />
                  <div>
                    <p className="text-foreground font-medium mb-1">Address</p>
                    <p className="text-muted-foreground font-light">
                      8419 Georgia Ave<br />
                      Silver Spring, MD 20910
                    </p>
                    <a
                      href="https://maps.google.com/?q=8419+Georgia+Ave+Silver+Spring+MD"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-accent text-sm mt-2 inline-block hover:underline"
                    >
                      Get directions →
                    </a>
                  </div>
                </div>

                <div className="flex gap-5">
                  <Phone className="text-accent mt-1 flex-shrink-0" size={20} />
                  <div>
                    <p className="text-foreground font-medium mb-1">Phone</p>
                    <a
                      href="tel:3015004783"
                      className="text-muted-foreground font-light hover:text-accent transition-colors"
                    >
                      (301) 500-4783
                    </a>
                  </div>
                </div>

                <div className="flex gap-5">
                  <Clock className="text-accent mt-1 flex-shrink-0" size={20} />
                  <div>
                    <p className="text-foreground font-medium mb-4">Hours</p>
                    <div className="space-y-2">
                      {HOURS.map((h, idx) => (
                        <div key={idx} className="flex justify-between gap-8 text-sm">
                          <span className="text-muted-foreground font-light">{h.day}</span>
                          <span className="text-foreground">{h.time}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-6">
              <div className="flex-1 bg-muted overflow-hidden min-h-64 relative">
                <ImageWithFallback
                  src={storefrontImg}
                  alt="Helen Hair Salon storefront at 8419 Georgia Ave Silver Spring"
                  className="w-full h-full object-cover opacity-70"
                />
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <div className="bg-background/90 backdrop-blur-sm border border-border px-8 py-6 text-center">
                    <p className="text-foreground font-semibold mb-1" style={{ fontFamily: "'Playfair Display', serif" }}>Downtown Silver Spring</p>
                    <p className="text-muted-foreground text-sm font-light">8419 Georgia Ave, MD 20910</p>
                    <a
                      href="https://maps.google.com/?q=8419+Georgia+Ave+Silver+Spring+MD"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-block mt-4 bg-primary text-primary-foreground text-xs px-5 py-2.5 uppercase tracking-widest hover:bg-accent transition-colors"
                    >
                      Open in Maps
                    </a>
                  </div>
                </div>
              </div>

              <a
                href="tel:3015004783"
                className="bg-primary text-primary-foreground py-5 text-center text-sm tracking-widest uppercase hover:bg-accent transition-colors font-medium"
              >
                Call (301) 500-4783
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#110a05] border-t border-border py-12">
        <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-8">
          <div>
            <p
              className="text-foreground text-lg font-semibold mb-1"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Helen Hair Salon
            </p>
            <p className="text-muted-foreground text-sm font-light">
              8419 Georgia Ave · Silver Spring, MD · (301) 500-4783
            </p>
          </div>

          <div className="flex items-center gap-6">
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram"
              className="text-muted-foreground hover:text-accent transition-colors"
            >
              <Instagram size={18} />
            </a>
            <a
              href="https://facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Facebook"
              className="text-muted-foreground hover:text-accent transition-colors"
            >
              <Facebook size={18} />
            </a>
            <a
              href="tel:3015004783"
              className="bg-primary text-primary-foreground text-xs px-5 py-2.5 uppercase tracking-widest hover:bg-accent transition-colors"
            >
              Book Now
            </a>
          </div>
        </div>

        <div className="max-w-6xl mx-auto px-6 mt-8 pt-6 border-t border-border">
          <p className="text-muted-foreground text-xs font-light">
            © {new Date().getFullYear()} Helen Hair Salon. All rights reserved. · Downtown Silver Spring, Maryland
          </p>
        </div>
      </footer>
    </div>
  );
}
